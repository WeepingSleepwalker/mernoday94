import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import DeleteButton from "../components/DeleteButton";
import axios from 'axios';


const IndexView = (props) => {
    const {id} = props; 
    const [authors, setAuthors] = useState([]);
    const [isdeleted, setisdeleted] = useState(false);
    
    useEffect(() => {
        axios.get("http://localhost:8000/api/author")
            .then((res) => {
                setAuthors(res.data.authors)
                console.log(res.data)

            })
            .catch(err => {
                console.log(err);
            })
    }, [isdeleted])

    
    return (
        <div >
            <h1>Authors</h1>
            <Link to="/create">Add Author</Link>
            <div>
                <ul>
                    {authors.map((author, index) => {
                        return (
                            <li key={index}><Link to={"/" + author._id}>{author.firstName} {author.lastName} </Link>| <Link to={"/edit/" + author._id}>Edit</Link> | <DeleteButton setDeleted = {setisdeleted} deleted = {isdeleted} id = {author._id}/> </li>
                        )
                    })}

                </ul>
            </div>

        </div>
    )

}
export default IndexView;