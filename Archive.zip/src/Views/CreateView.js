import React, { useState } from 'react';
import Form from '../components/Form';
import axios from 'axios';
import { useHistory, useParams } from 'react-router-dom';


const CreateView = (props) => {

    const { id } = useParams();
    const [firstName, setfirstName] = useState("");
    const [lastName, setlastName] = useState("");
    const [novel, setNovel] = useState("");
    const [quote, setQuote] = useState("");
    // const [form, setForm] = useState({
    // firstName 
    // lastName 
    // novel 
    // quote     // });
    const [loaded, setLoaded] = useState(false);
    const history = useHistory();
    const [errors, setErrors] = useState([]);
    const [dbErrors, setDBErrors] = useState([]);

    // const onChangeHandler = (e) =>{
    //     e.preventDefault();
    //     setForm({
    //         ...form,
    //         [e.target.name]:e.target.value
    //     })
    // }

    const onSubmitHandler2 = (e) => {
        e.preventDefault();


        //make a post request to create a new person
        axios.post('http://localhost:8000/api/author',{
            firstName, 
            lastName, 
            novel, 
            quote 
        })
            .then(res=>{
                console.log(res.data) 
                history.push('/')
            })
            .catch(err =>{ 
                
                console.log("?????", err.response.data.error.errors);
                const {errors} = err.response.data.error;
                const messages = Object.keys(errors).map( error => errors[error].message )
                console.log(messages);
                setDBErrors(messages);
            })




    }
    return (
        <div style={{ display: 'flex', justifyContent: 'center' }}>
            <h1>create authors</h1>
            {
                dbErrors.map((err, index) => <p key={index} style={{color: "red"}}>{err}</p>)
            }
            <form onSubmit={onSubmitHandler2}>
                <p>
                    <label>First Name</label>
                    <input type="text"  onChange={(e) => setfirstName(e.target.value)} value={firstName}/>
                </p>
                <p>
                    <label>Last Name</label>
                    <input type="text"  onChange={(e) => setlastName(e.target.value)} value={lastName}/>
                </p>
                <p>
                    <label>Novel/Poem</label>
                    <input type="text" onChange={(e) => setNovel(e.target.value)} value={novel} />
                </p>
                <p>
                    <label>Quote</label>
                    <textarea type="text" onChange={(e) => setQuote(e.target.value)} value={quote} ></textarea>
                </p>
                <input type="submit" />


            </form>
        </div>
    )
}

export default CreateView
