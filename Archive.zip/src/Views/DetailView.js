import React, {useState, useEffect }from 'react'
import DeleteButton from '../components/DeleteButton';
import Axios from 'axios';
import {useParams} from 'react-router-dom'

const DetailView = (props) => {
    const {id} = useParams();
    const [firstName, setfirstName] = useState("");
    const [lastName, setlastName] = useState("");
    const [novel, setNovel] = useState("");
    const [quote, setQuote] = useState("");


    useEffect( () => {
        Axios.get(`http://localhost:8000/api/author/${id}`)
        .then( (res) => {
            
            setfirstName(res.data.author.firstName);
            setlastName(res.data.author.lastName);
            setNovel(res.data.author.novel);
            setQuote(res.data.author.quote);

        })
        .catch( (err) => {
            console.error(err);
        })

    }, [id]);

    return (
        <div style={{display: 'block', justifyContent: 'center'}}>
            <h3>{firstName} {lastName}</h3>
            <p>Novel: {novel}</p>
            <p>Quote: {quote}</p>
            <DeleteButton id = {id}/>
        </div>
    )
}

export default DetailView
