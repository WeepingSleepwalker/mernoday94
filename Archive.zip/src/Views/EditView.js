import React, { useEffect, useState } from 'react'
import DeleteButton from '../components/DeleteButton';
import Form from '../components/Form';
import axios from 'axios';
import { useParams, useHistory } from 'react-router-dom';


const EditView = (props) => {
    const { id } = useParams();
    const { onSubmitHandler, initialFirst, initialLast, initialNovel, initialQuote, onSubmitProp } = props;
    const [firstName, setfirstName] = useState("");
    const [lastName, setlastName] = useState("");
    const [novel, setNovel] = useState("");
    const [quote, setQuote] = useState("");
    const [loaded, setLoaded] = useState(false);
    const history = useHistory();

    useEffect(() => {
        axios.get('http://localhost:8000/api/author/' + id)
            .then(res => {

                setfirstName(res.data.author.firstName);
                setlastName(res.data.author.lastName);
                setNovel(res.data.author.novel);
                setQuote(res.data.author.quote);
                setLoaded(true);
                console.log('im here');
                console.log(res.data);

            })
    }, []);

    const onSubmitHandler1 = (e) => {
        e.preventDefault();
        console.log("submitted form-----")


        //make a post request to create a new person
        axios.put('http://localhost:8000/api/author/' + id, {
            firstName,
            lastName,
            novel,
            quote

        })

            .then(res => {
                console.log(res.data)
                history.push('/')
            })
            .catch(err => console.log(err))
        



    }
    return (
        <div>
            <h3>THis is edit view {lastName} </h3>
            {loaded &&
            <form onSubmit={onSubmitHandler1}>
            <p>

                <label>First Name</label>
                <input type="text" onChange={(e) => setfirstName(e.target.value)} value={firstName} />
            </p>
            <p>
                <label>Last Name</label>
                <input type="text" onChange={(e) => setlastName(e.target.value)} value={lastName} />
            </p>
            <p>
                <label>Novel/Poem</label>
                <input type="text" onChange={(e) => setNovel(e.target.value)} value={novel} />
            </p>
            <p>
                <label>Quote</label>
                <textarea type="text" onChange={(e) => setQuote(e.target.value)} value={quote} ></textarea>
            </p>
            <input type="submit" /></form>
            }
            <DeleteButton id = {id}/>

        </div>
    )
}

export default EditView
