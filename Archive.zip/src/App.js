
import './App.css';
import { Route, Switch, Redirect } from 'react-router-dom';
import IndexView from './Views/IndexView'
import CreateView from './Views/CreateView';
import DetailView from './Views/DetailView';
import EditView from './Views/EditView';


function App() {


  return (
    <div >
      <header className="App-header">
     
        <Switch>

          <Route path='/edit/:id'>
            <EditView />
          </Route>

          <Route exact path='/create'>
            <CreateView />
          </Route>



          <Route path='/:id'>
            <DetailView />
          </Route> 

           <Route path='/'>
            <IndexView />
          </Route>

        </Switch>

      </header>
    </div>
  );
}

export default App;
