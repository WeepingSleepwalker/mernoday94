import React from 'react'
import axios from 'axios'
import { useHistory } from 'react-router'

const DeleteButton = (props) => {
    const {id, deleted, setDeleted} = props;
    
    const history = useHistory();

    const onClickHandler = e => {
        axios.delete('http://localhost:8000/api/author/' + id)
            .then(response =>{
                console.log(response);
                setDeleted(!deleted);
                history.push('/');
            })
            .catch(err => {
                console.log(err);
        })
    }
    return (
        <div>
            <button onClick = {onClickHandler }>Delete</button>
        </div>
    )
}

export default DeleteButton
