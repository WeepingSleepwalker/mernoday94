import React, { useState } from 'react';
import axios from 'axios';
import { useHistory, useParams } from 'react-router-dom';


const Form = (props) => {
    const { id } = useParams();
    const { onSubmitHandler, initialFirst, initialLast, initialNovel, initialQuote, onSubmitProp } = props;
    const [firstName, setfirstName] = useState(initialFirst);
    const [lastName, setlastName] = useState(initialLast);
    const [novel, setNovel] = useState(initialNovel);
    const [quote, setQuote] = useState(initialQuote);
    const history = useHistory();


    //handler when the form is submitted
    // const onSubmitHandler = e => {
    //     e.preventDefault();
    //     onSubmitProp({firstName, lastName, novel, quote});
    // }

    return (

        <form onSubmit={onSubmitHandler}>
            <p>
                <label>First Name</label>
                <input type="text" value={firstName} onChange={(e) => setfirstName(e.target.value)} />
            </p>
            <p>
                <label>Last Name</label>
                <input type="text" value={lastName} onChange={(e) => setlastName(e.target.value)} />
            </p>
            <p>
                <label>Novel/Poem</label>
                <input type="text" value={novel} onChange={(e) => setNovel(e.target.value)} />
            </p>
            <p>
                <label>Quote</label>
                <textarea type="text" value={quote} onChange={(e) => setQuote(e.target.value)} ></textarea>
            </p>
            <input type="submit" />


        </form>

    )
}

export default Form
